package com.example.multipaymentgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MultiPaymentGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
